minibzip2
---------

Usage:


  minibzip2 [filename]

  Will create (or overwrite) a file [filename].bz2 with the bzipped
  contents of [filename]

  minibzip2 -d [filename].bz2

  Will create (or overwrite) a file [filename] with the bunzipped
  contents of [filename]